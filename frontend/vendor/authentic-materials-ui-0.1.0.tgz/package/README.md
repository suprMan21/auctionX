# @authentic-materials/ui

The Authentic Materials design system. **Material Design 3 is the blueprint, AM is the look.**

- M3 supplies the structure: color roles, the 15-role type scale, shape scale, elevation,
  state layers, motion tokens, window size classes and the full component catalogue with
  its anatomy, states and accessibility behavior.
- AM supplies the visual language: dark mode only, the violet-to-blue brand gradient,
  glass surfaces, Plus Jakarta Sans and Heroicons.
- Two themes share one component set: **App** (glass, rounded) for the product and
  **Cinema** (solid `#070709`, sharp 4/8px corners, uppercase display type) for landing routes,
  per the Locked 2026-05-08 Live Nation Cinematic decision.

Built with React 19, TypeScript, Tailwind 3.4, Headless UI 2 and class-variance-authority.

## Quick start

```bash
npm install
npm run dev          # playground at http://localhost:5173 (every component, both themes)
npm run check        # typecheck + tests + contrast gate + build
```

| Script | What it does |
|---|---|
| `npm run tokens` | Regenerates `src/styles/tokens.css` from `src/tokens` (the source of truth) |
| `npm run contrast` | Fails if any role pairing misses WCAG 2.2 AA (4.5:1 text, 3:1 UI) in any theme |
| `npm test` | Vitest + Testing Library + axe on every component |
| `npm run build` | Library (ESM + CJS + d.ts) and `dist/styles.css` |
| `npm run build:playground` | Static playground in `playground-dist/` |

## Using it in an app

```ts
// tailwind.config.js
import { amPreset } from '@authentic-materials/ui/tailwind-preset';
export default {
  presets: [amPreset],
  content: ['./index.html', './src/**/*.{ts,tsx}', './node_modules/@authentic-materials/ui/dist/**/*.{js,cjs}'],
};
```

```ts
// main.tsx
import '@authentic-materials/ui/styles.css'; // tokens + base layer (state layers, glass, focus, reduced motion)
import './index.css';                          // your @tailwind directives
```

```tsx
import { Button, TextField } from '@authentic-materials/ui';

<html data-theme="app">   {/* or "cinema" on landing routes */}
<Button variant="filled">Place bid</Button>
```

Load Plus Jakarta Sans (400 to 800) in your HTML; the token stack falls back to system fonts.

## Layout

```
src/tokens/        ref.ts (palette) + sys.ts (roles, themes, type, shape, motion)  <- edit here
src/styles/        tokens.css (generated) + base.css (state layer, glass, focus, motion)
src/tailwind-preset.ts
src/components/    one folder per M3 family
playground/        living showcase (replaces design/component-showcase.html)
docs/              M3 mapping, foundations, adoption guide
AGENTS.md          contributor conventions (humans and agents)
```

## Docs

- [docs/M3_MAPPING.md](docs/M3_MAPPING.md): every M3 foundation and component, and what AM does with it
- [docs/FOUNDATIONS.md](docs/FOUNDATIONS.md): token reference and the rules behind them
- [docs/ADOPTION.md](docs/ADOPTION.md): migrating the AM frontend onto this package
- [AGENTS.md](AGENTS.md): how to build a component here
